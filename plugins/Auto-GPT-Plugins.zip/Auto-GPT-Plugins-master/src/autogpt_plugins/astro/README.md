# Auto-GPT Space Plugin
This plugin enables AutoGPT to see how many people are in space. This can help enable AutoGPT to better achieve its goals

## Use cases
 - Researching how many people are in space
## Setup
Setup is easy. Just follow the instructions in [Auto-GPT-Plugins/README.md](https://github.com/Significant-Gravitas/Auto-GPT-Plugins/blob/master/README.md)
